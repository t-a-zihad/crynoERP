<div class="login-header box-shadow">
			<div
				class="container-fluid d-flex justify-content-between align-items-center"
			>
				<div class="brand-logo">
					<a href="#">
						<img src="{{ asset('src\images\cryno-long-logo.png') }}" alt="" />
					</a>
				</div>

			</div>
		</div>

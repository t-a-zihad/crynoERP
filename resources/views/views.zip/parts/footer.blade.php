<footer class="footer-wrap pd-20 mb-20 card-box">
    CrynoERP - v1.0.0
</footer>

<style>
    footer{
        margin-top: 20px;
    }
</style>
